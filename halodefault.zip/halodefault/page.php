<!DOCTYPE html>
<html class="no-js" <?php language_attributes(); ?>>
<?php get_template_part('templates/head'); ?>
<body <?php body_class(); ?>>
  <div class="wrap container-fluid">
	<div class="row">
		<div class="content col-sm-12 col-md-8">
			<?php 
				if ( !empty ( $GLOBALS['wp_customize'] ) ) {
					get_template_part('templates/content', 'preview'); 
				} else {
					get_template_part('templates/content', 'page'); 
				}
			?>
		</div>
		<div class="side-bar col-sm-12 col-md-4">
			<?php 
			get_template_part('templates/sidebar', ''); 
			?>
		</div>
	</div>
  </div>
  <div class="row">
	<?php get_footer(); ?>
  </div>
</body>
</html>

