<?php
// Get sidebar halo widgets
$widgetList = array();
$widgetList[] = array('title' => 'HaloSocial Site Members', 	'value' => 'widgets.sitemembers');
$widgetList[] = array('title' => 'HaloSocial Events', 'value' => 'widgets.upcomingevents');
$widgetList[] = array('title' => 'HaloSocial Featured Pages', 	'value' => 'widgets.featuredpages');
$widgetList[] = array('title' => 'HaloSocial Popular Groups', 	'value' => 'widgets.populargroups');

echo '<div id="halo-default-sidebar-primary">';
foreach ($widgetList as $widget) {
    echo HALOUIBuilder::getInstance('', 'div_wrapper', array(
        'html' => HALOUIBuilder::getInstance('', $widget['value'], array('title' => $widget['title']))->fetch(),
        'class' => 'halo-singe-wrap halo-widget-wrapper'
    ))->fetch();
}
echo '</div>';

// Get the default theme wp-includes/theme-compat/sidebar.php
get_sidebar();
?>