<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php wp_title('|', true, 'right'); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

<?php 
if ( !empty ( $GLOBALS['wp_customize'] ) ) {
	$_GET['page_id'] = halo_getPageId();	//force to load stacking social page
	$_GET['view'] = 'home';
	$_GET['task'] = 'getIndex';
	halo_init();
	Input::merge(array('view'=>'home', 'task'=>'getIndex'));
}
?>  
  <?php wp_head(); ?>
</head>
