<?php
	$haloPageId = halo_getPageId();
	$haloPage = get_post($haloPageId);
	$content = $haloPage->post_content;
	$content = apply_filters('the_content', $content);
	$content = str_replace(']]>', ']]>', $content);
	echo $content;
?>
