<?php
/**
 * Enqueue scripts and stylesheets
 *
 * Enqueue stylesheets in the following order:
 *
 * Enqueue scripts in the following order:
 */
function halo_enqueue_scripts_cb() {
	if(halo_isHalo()){
		if(is_admin()){
			halosocial_admin_enqueue_styles();
			halosocial_admin_enqueue_scripts();
		} else {

			//wp_deregister_script('jquery');
			halosocial_enqueue_styles($loadBoostrap=true);
			halosocial_enqueue_scripts($loadjQuery = true, $loadBoostrap=true);
		}
	}
}
add_action('wp_enqueue_scripts', 'halo_enqueue_scripts_cb', 100);
