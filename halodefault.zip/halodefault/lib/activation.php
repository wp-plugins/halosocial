<?php
/**
 * Theme activation
 */
if (is_admin() && isset($_GET['activated']) && 'themes.php' == $GLOBALS['pagenow']) {
  wp_redirect(admin_url('themes.php?page=theme_activation_options'));
  exit;
}

function halo_theme_activation_options_init() {
  register_setting(
    'halo_activation_options',
    'halo_theme_activation_options'
  );
}
add_action('admin_init', 'halo_theme_activation_options_init');

function halo_activation_options_page_capability($capability) {
  return 'edit_theme_options';
}
add_filter('option_page_capability_halo_activation_options', 'halo_activation_options_page_capability');

function halo_theme_activation_options_add_page() {
  $halo_activation_options = halo_get_theme_activation_options();

  if (!$halo_activation_options) {
    $theme_page = add_theme_page(
      __('Theme Activation', 'halo'),
      __('Theme Activation', 'halo'),
      'edit_theme_options',
      'theme_activation_options',
      'halo_theme_activation_options_render_page'
    );
  } else {
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'theme_activation_options') {
      flush_rewrite_rules();
      wp_redirect(admin_url('themes.php'));
      exit;
    }
  }
}
add_action('admin_menu', 'halo_theme_activation_options_add_page', 50);

function halo_get_theme_activation_options() {
  return get_option('halo_theme_activation_options');
}

function halo_theme_activation_options_render_page() {
?>
  <div class="wrap">
    <h2><?php printf(__('%s Theme Activation', 'halo'), wp_get_theme()); ?></h2>
    <div class="update-nag">
      <?php _e('You do not need activate this template manually. This tempalte will be applied automatically when user access to HaloSocial pages', 'halo'); ?>
    </div>

    <form method="post" action="themes.php">
      <?php submit_button(); ?>
    </form>
  </div>

<?php 
}

function halo_deactivation() {
  delete_option('halo_theme_activation_options');
}
add_action('switch_theme', 'halo_deactivation');
